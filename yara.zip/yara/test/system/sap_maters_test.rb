require "application_system_test_case"

class SapMatersTest < ApplicationSystemTestCase
  setup do
    @sap_mater = sap_maters(:one)
  end

  test "visiting the index" do
    visit sap_maters_url
    assert_selector "h1", text: "Sap Maters"
  end

  test "creating a Sap mater" do
    visit sap_maters_url
    click_on "New Sap Mater"

    fill_in "Approved id", with: @sap_mater.approved_id_id
    fill_in "Status", with: @sap_mater.status
    click_on "Create Sap mater"

    assert_text "Sap mater was successfully created"
    click_on "Back"
  end

  test "updating a Sap mater" do
    visit sap_maters_url
    click_on "Edit", match: :first

    fill_in "Approved id", with: @sap_mater.approved_id_id
    fill_in "Status", with: @sap_mater.status
    click_on "Update Sap mater"

    assert_text "Sap mater was successfully updated"
    click_on "Back"
  end

  test "destroying a Sap mater" do
    visit sap_maters_url
    page.accept_confirm do
      click_on "Destroy", match: :first
    end

    assert_text "Sap mater was successfully destroyed"
  end
end
