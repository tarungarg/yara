require "application_system_test_case"

class SuggestionTypesTest < ApplicationSystemTestCase
  setup do
    @suggestion_type = suggestion_types(:one)
  end

  test "visiting the index" do
    visit suggestion_types_url
    assert_selector "h1", text: "Suggestion Types"
  end

  test "creating a Suggestion type" do
    visit suggestion_types_url
    click_on "New Suggestion Type"

    fill_in "Reward amount", with: @suggestion_type.reward_amount
    fill_in "Reward type", with: @suggestion_type.reward_type
    fill_in "Suggestion type", with: @suggestion_type.suggestion_type
    click_on "Create Suggestion type"

    assert_text "Suggestion type was successfully created"
    click_on "Back"
  end

  test "updating a Suggestion type" do
    visit suggestion_types_url
    click_on "Edit", match: :first

    fill_in "Reward amount", with: @suggestion_type.reward_amount
    fill_in "Reward type", with: @suggestion_type.reward_type
    fill_in "Suggestion type", with: @suggestion_type.suggestion_type
    click_on "Update Suggestion type"

    assert_text "Suggestion type was successfully updated"
    click_on "Back"
  end

  test "destroying a Suggestion type" do
    visit suggestion_types_url
    page.accept_confirm do
      click_on "Destroy", match: :first
    end

    assert_text "Suggestion type was successfully destroyed"
  end
end
