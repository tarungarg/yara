class Meeting < ApplicationRecord
  belongs_to :company_address
  belongs_to :admin_id, class_name: 'Employee', foreign_key: 'employee_id'
  belongs_to :room_time_slot
end
