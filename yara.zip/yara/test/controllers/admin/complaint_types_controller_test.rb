require 'test_helper'

class Admin::ComplaintTypesControllerTest < ActionDispatch::IntegrationTest
  setup do
    @admin_complaint_type = admin_complaint_types(:one)
  end

  test "should get index" do
    get admin_complaint_types_url
    assert_response :success
  end

  test "should get new" do
    get new_admin_complaint_type_url
    assert_response :success
  end

  test "should create admin_complaint_type" do
    assert_difference('Admin::ComplaintType.count') do
      post admin_complaint_types_url, params: { admin_complaint_type: { complaint_type: @admin_complaint_type.complaint_type, role_id: @admin_complaint_type.role_id } }
    end

    assert_redirected_to admin_complaint_type_url(Admin::ComplaintType.last)
  end

  test "should show admin_complaint_type" do
    get admin_complaint_type_url(@admin_complaint_type)
    assert_response :success
  end

  test "should get edit" do
    get edit_admin_complaint_type_url(@admin_complaint_type)
    assert_response :success
  end

  test "should update admin_complaint_type" do
    patch admin_complaint_type_url(@admin_complaint_type), params: { admin_complaint_type: { complaint_type: @admin_complaint_type.complaint_type, role_id: @admin_complaint_type.role_id } }
    assert_redirected_to admin_complaint_type_url(@admin_complaint_type)
  end

  test "should destroy admin_complaint_type" do
    assert_difference('Admin::ComplaintType.count', -1) do
      delete admin_complaint_type_url(@admin_complaint_type)
    end

    assert_redirected_to admin_complaint_types_url
  end
end
