class CreateComplaintTypes < ActiveRecord::Migration[6.0]
  def change
    create_table :complaint_types do |t|
      t.references :role, null: false, foreign_key: true
      t.string :complaint_type

      t.timestamps
    end
  end
end
