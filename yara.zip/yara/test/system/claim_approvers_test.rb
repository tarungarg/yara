require "application_system_test_case"

class ClaimApproversTest < ApplicationSystemTestCase
  setup do
    @claim_approver = claim_approvers(:one)
  end

  test "visiting the index" do
    visit claim_approvers_url
    assert_selector "h1", text: "Claim Approvers"
  end

  test "creating a Claim approver" do
    visit claim_approvers_url
    click_on "New Claim Approver"

    fill_in "Department role id", with: @claim_approver.department_role_id_id
    click_on "Create Claim approver"

    assert_text "Claim approver was successfully created"
    click_on "Back"
  end

  test "updating a Claim approver" do
    visit claim_approvers_url
    click_on "Edit", match: :first

    fill_in "Department role id", with: @claim_approver.department_role_id_id
    click_on "Update Claim approver"

    assert_text "Claim approver was successfully updated"
    click_on "Back"
  end

  test "destroying a Claim approver" do
    visit claim_approvers_url
    page.accept_confirm do
      click_on "Destroy", match: :first
    end

    assert_text "Claim approver was successfully destroyed"
  end
end
