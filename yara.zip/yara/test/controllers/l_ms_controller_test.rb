require 'test_helper'

class LMsControllerTest < ActionDispatch::IntegrationTest
  setup do
    @lm = lms(:one)
  end

  test "should get index" do
    get lms_index_url
    assert_response :success
  end

  test "should get new" do
    get new_lm_url
    assert_response :success
  end

  test "should create lm" do
    assert_difference('Lms.count') do
      post lms_index_url, params: { lm: { attachment_id_id: @lm.attachment_id_id, employee_id_id: @lm.employee_id_id, leave_approver_id_id: @lm.leave_approver_id_id, leave_type_id_id: @lm.leave_type_id_id, reason: @lm.reason, reason_by_approver: @lm.reason_by_approver, status: @lm.status } }
    end

    assert_redirected_to lm_url(Lms.last)
  end

  test "should show lm" do
    get lm_url(@lm)
    assert_response :success
  end

  test "should get edit" do
    get edit_lm_url(@lm)
    assert_response :success
  end

  test "should update lm" do
    patch lm_url(@lm), params: { lm: { attachment_id_id: @lm.attachment_id_id, employee_id_id: @lm.employee_id_id, leave_approver_id_id: @lm.leave_approver_id_id, leave_type_id_id: @lm.leave_type_id_id, reason: @lm.reason, reason_by_approver: @lm.reason_by_approver, status: @lm.status } }
    assert_redirected_to lm_url(@lm)
  end

  test "should destroy lm" do
    assert_difference('Lms.count', -1) do
      delete lm_url(@lm)
    end

    assert_redirected_to lms_index_url
  end
end
