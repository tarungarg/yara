require 'test_helper'

class CmsControllerTest < ActionDispatch::IntegrationTest
  setup do
    @cm = cms(:one)
  end

  test "should get index" do
    get cms_url
    assert_response :success
  end

  test "should get new" do
    get new_cm_url
    assert_response :success
  end

  test "should create cm" do
    assert_difference('Cm.count') do
      post cms_url, params: { cm: { claim_approvers_id_id: @cm.claim_approvers_id_id, claim_type_id_id: @cm.claim_type_id_id, status: @cm.status } }
    end

    assert_redirected_to cm_url(Cm.last)
  end

  test "should show cm" do
    get cm_url(@cm)
    assert_response :success
  end

  test "should get edit" do
    get edit_cm_url(@cm)
    assert_response :success
  end

  test "should update cm" do
    patch cm_url(@cm), params: { cm: { claim_approvers_id_id: @cm.claim_approvers_id_id, claim_type_id_id: @cm.claim_type_id_id, status: @cm.status } }
    assert_redirected_to cm_url(@cm)
  end

  test "should destroy cm" do
    assert_difference('Cm.count', -1) do
      delete cm_url(@cm)
    end

    assert_redirected_to cms_url
  end
end
