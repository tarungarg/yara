require 'test_helper'

class LeaveApproverTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
