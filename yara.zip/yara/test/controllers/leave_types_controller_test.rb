require 'test_helper'

class LeaveTypesControllerTest < ActionDispatch::IntegrationTest
  setup do
    @leave_type = leave_types(:one)
  end

  test "should get index" do
    get leave_types_url
    assert_response :success
  end

  test "should get new" do
    get new_leave_type_url
    assert_response :success
  end

  test "should create leave_type" do
    assert_difference('LeaveType.count') do
      post leave_types_url, params: { leave_type: { auto_approve: @leave_type.auto_approve, docs_required: @leave_type.docs_required, holiday_days: @leave_type.holiday_days, leave_disabled: @leave_type.leave_disabled, leave_name: @leave_type.leave_name, leaves_per_month: @leave_type.leaves_per_month, limits: @leave_type.limits, location_id_id: @leave_type.location_id_id } }
    end

    assert_redirected_to leave_type_url(LeaveType.last)
  end

  test "should show leave_type" do
    get leave_type_url(@leave_type)
    assert_response :success
  end

  test "should get edit" do
    get edit_leave_type_url(@leave_type)
    assert_response :success
  end

  test "should update leave_type" do
    patch leave_type_url(@leave_type), params: { leave_type: { auto_approve: @leave_type.auto_approve, docs_required: @leave_type.docs_required, holiday_days: @leave_type.holiday_days, leave_disabled: @leave_type.leave_disabled, leave_name: @leave_type.leave_name, leaves_per_month: @leave_type.leaves_per_month, limits: @leave_type.limits, location_id_id: @leave_type.location_id_id } }
    assert_redirected_to leave_type_url(@leave_type)
  end

  test "should destroy leave_type" do
    assert_difference('LeaveType.count', -1) do
      delete leave_type_url(@leave_type)
    end

    assert_redirected_to leave_types_url
  end
end
