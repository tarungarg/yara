class Complaint < ApplicationRecord
  belongs_to :employee
  belongs_to :complaint_type
  belongs_to :role
  belongs_to :attachment
end
