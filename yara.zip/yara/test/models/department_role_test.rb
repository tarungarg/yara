require 'test_helper'

class DepartmentRoleTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
