class ComplaintType < ApplicationRecord
  belongs_to :role
end
