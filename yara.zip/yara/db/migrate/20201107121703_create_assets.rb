class CreateAssets < ActiveRecord::Migration[6.0]
  def change
    create_table :assets do |t|
      t.references :employee, null: false, foreign_key: true
      t.references :department, null: false, foreign_key: true
      t.string :item
      t.references :assigned_by, null: false, foreign_key: true
      t.integer :qty
      t.integer :threshhold
      t.text :item_details

      t.timestamps
    end
  end
end
