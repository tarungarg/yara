require 'test_helper'

class SuggestionApprovalsControllerTest < ActionDispatch::IntegrationTest
  setup do
    @suggestion_approval = suggestion_approvals(:one)
  end

  test "should get index" do
    get suggestion_approvals_url
    assert_response :success
  end

  test "should get new" do
    get new_suggestion_approval_url
    assert_response :success
  end

  test "should create suggestion_approval" do
    assert_difference('SuggestionApproval.count') do
      post suggestion_approvals_url, params: { suggestion_approval: { rank: @suggestion_approval.rank, role_id: @suggestion_approval.role_id, suggestion_approval_id_id: @suggestion_approval.suggestion_approval_id_id } }
    end

    assert_redirected_to suggestion_approval_url(SuggestionApproval.last)
  end

  test "should show suggestion_approval" do
    get suggestion_approval_url(@suggestion_approval)
    assert_response :success
  end

  test "should get edit" do
    get edit_suggestion_approval_url(@suggestion_approval)
    assert_response :success
  end

  test "should update suggestion_approval" do
    patch suggestion_approval_url(@suggestion_approval), params: { suggestion_approval: { rank: @suggestion_approval.rank, role_id: @suggestion_approval.role_id, suggestion_approval_id_id: @suggestion_approval.suggestion_approval_id_id } }
    assert_redirected_to suggestion_approval_url(@suggestion_approval)
  end

  test "should destroy suggestion_approval" do
    assert_difference('SuggestionApproval.count', -1) do
      delete suggestion_approval_url(@suggestion_approval)
    end

    assert_redirected_to suggestion_approvals_url
  end
end
