require "application_system_test_case"

class CmsTest < ApplicationSystemTestCase
  setup do
    @cm = cms(:one)
  end

  test "visiting the index" do
    visit cms_url
    assert_selector "h1", text: "Cms"
  end

  test "creating a Cm" do
    visit cms_url
    click_on "New Cm"

    fill_in "Claim approvers id", with: @cm.claim_approvers_id_id
    fill_in "Claim type id", with: @cm.claim_type_id_id
    fill_in "Status", with: @cm.status
    click_on "Create Cm"

    assert_text "Cm was successfully created"
    click_on "Back"
  end

  test "updating a Cm" do
    visit cms_url
    click_on "Edit", match: :first

    fill_in "Claim approvers id", with: @cm.claim_approvers_id_id
    fill_in "Claim type id", with: @cm.claim_type_id_id
    fill_in "Status", with: @cm.status
    click_on "Update Cm"

    assert_text "Cm was successfully updated"
    click_on "Back"
  end

  test "destroying a Cm" do
    visit cms_url
    page.accept_confirm do
      click_on "Destroy", match: :first
    end

    assert_text "Cm was successfully destroyed"
  end
end
