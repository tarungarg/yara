require 'test_helper'

class SapApprovalsControllerTest < ActionDispatch::IntegrationTest
  setup do
    @sap_approval = sap_approvals(:one)
  end

  test "should get index" do
    get sap_approvals_url
    assert_response :success
  end

  test "should get new" do
    get new_sap_approval_url
    assert_response :success
  end

  test "should create sap_approval" do
    assert_difference('SapApproval.count') do
      post sap_approvals_url, params: { sap_approval: { approval_id_id: @sap_approval.approval_id_id, rank: @sap_approval.rank, sap_master_id: @sap_approval.sap_master_id } }
    end

    assert_redirected_to sap_approval_url(SapApproval.last)
  end

  test "should show sap_approval" do
    get sap_approval_url(@sap_approval)
    assert_response :success
  end

  test "should get edit" do
    get edit_sap_approval_url(@sap_approval)
    assert_response :success
  end

  test "should update sap_approval" do
    patch sap_approval_url(@sap_approval), params: { sap_approval: { approval_id_id: @sap_approval.approval_id_id, rank: @sap_approval.rank, sap_master_id: @sap_approval.sap_master_id } }
    assert_redirected_to sap_approval_url(@sap_approval)
  end

  test "should destroy sap_approval" do
    assert_difference('SapApproval.count', -1) do
      delete sap_approval_url(@sap_approval)
    end

    assert_redirected_to sap_approvals_url
  end
end
