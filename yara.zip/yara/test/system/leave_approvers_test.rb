require "application_system_test_case"

class LeaveApproversTest < ApplicationSystemTestCase
  setup do
    @leave_approver = leave_approvers(:one)
  end

  test "visiting the index" do
    visit leave_approvers_url
    assert_selector "h1", text: "Leave Approvers"
  end

  test "creating a Leave approver" do
    visit leave_approvers_url
    click_on "New Leave Approver"

    fill_in "Leave applied by", with: @leave_approver.leave_applied_by
    fill_in "Leave approvers", with: @leave_approver.leave_approvers
    fill_in "Leave type", with: @leave_approver.leave_type_id
    click_on "Create Leave approver"

    assert_text "Leave approver was successfully created"
    click_on "Back"
  end

  test "updating a Leave approver" do
    visit leave_approvers_url
    click_on "Edit", match: :first

    fill_in "Leave applied by", with: @leave_approver.leave_applied_by
    fill_in "Leave approvers", with: @leave_approver.leave_approvers
    fill_in "Leave type", with: @leave_approver.leave_type_id
    click_on "Update Leave approver"

    assert_text "Leave approver was successfully updated"
    click_on "Back"
  end

  test "destroying a Leave approver" do
    visit leave_approvers_url
    page.accept_confirm do
      click_on "Destroy", match: :first
    end

    assert_text "Leave approver was successfully destroyed"
  end
end
