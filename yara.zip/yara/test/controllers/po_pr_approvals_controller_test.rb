require 'test_helper'

class PoPrApprovalsControllerTest < ActionDispatch::IntegrationTest
  setup do
    @po_pr_approval = po_pr_approvals(:one)
  end

  test "should get index" do
    get po_pr_approvals_url
    assert_response :success
  end

  test "should get new" do
    get new_po_pr_approval_url
    assert_response :success
  end

  test "should create po_pr_approval" do
    assert_difference('PoPrApproval.count') do
      post po_pr_approvals_url, params: { po_pr_approval: { approved_id_id: @po_pr_approval.approved_id_id, status: @po_pr_approval.status } }
    end

    assert_redirected_to po_pr_approval_url(PoPrApproval.last)
  end

  test "should show po_pr_approval" do
    get po_pr_approval_url(@po_pr_approval)
    assert_response :success
  end

  test "should get edit" do
    get edit_po_pr_approval_url(@po_pr_approval)
    assert_response :success
  end

  test "should update po_pr_approval" do
    patch po_pr_approval_url(@po_pr_approval), params: { po_pr_approval: { approved_id_id: @po_pr_approval.approved_id_id, status: @po_pr_approval.status } }
    assert_redirected_to po_pr_approval_url(@po_pr_approval)
  end

  test "should destroy po_pr_approval" do
    assert_difference('PoPrApproval.count', -1) do
      delete po_pr_approval_url(@po_pr_approval)
    end

    assert_redirected_to po_pr_approvals_url
  end
end
