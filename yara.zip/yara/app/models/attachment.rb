class Attachment < ApplicationRecord
end
