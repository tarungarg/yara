class Admin::SuggestionTypesController < ApplicationController
  before_action :set_suggestion_type, only: [:show, :edit, :update, :destroy]

  # GET /suggestion_types
  # GET /suggestion_types.json
  def index
    @suggestion_types = SuggestionType.all
  end

  # GET /suggestion_types/1
  # GET /suggestion_types/1.json
  def show
  end

  # GET /suggestion_types/new
  def new
    @suggestion_type = SuggestionType.new
  end

  # GET /suggestion_types/1/edit
  def edit
  end

  # POST /suggestion_types
  # POST /suggestion_types.json
  def create
    @suggestion_type = SuggestionType.new(suggestion_type_params)

    respond_to do |format|
      if @suggestion_type.save
        format.html { redirect_to @suggestion_type, notice: 'Suggestion type was successfully created.' }
        format.json { render :show, status: :created, location: @suggestion_type }
      else
        format.html { render :new }
        format.json { render json: @suggestion_type.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /suggestion_types/1
  # PATCH/PUT /suggestion_types/1.json
  def update
    respond_to do |format|
      if @suggestion_type.update(suggestion_type_params)
        format.html { redirect_to @suggestion_type, notice: 'Suggestion type was successfully updated.' }
        format.json { render :show, status: :ok, location: @suggestion_type }
      else
        format.html { render :edit }
        format.json { render json: @suggestion_type.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /suggestion_types/1
  # DELETE /suggestion_types/1.json
  def destroy
    @suggestion_type.destroy
    respond_to do |format|
      format.html { redirect_to suggestion_types_url, notice: 'Suggestion type was successfully destroyed.' }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_suggestion_type
      @suggestion_type = SuggestionType.find(params[:id])
    end

    # Only allow a list of trusted parameters through.
    def suggestion_type_params
      params.require(:suggestion_type).permit(:suggestion_type, :reward_type, :reward_amount)
    end
end
