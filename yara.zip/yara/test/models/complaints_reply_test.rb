require 'test_helper'

class ComplaintsReplyTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
