class CreateLeaveApprovers < ActiveRecord::Migration[6.0]
  def change
    create_table :leave_approvers do |t|
      t.references :leave_type_id
      t.references :leave_applied_by
      t.text :leave_approvers

      t.timestamps
    end
  end
end
