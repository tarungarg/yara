class LeaveType < ApplicationRecord
  belongs_to :location_id
end
