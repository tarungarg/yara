class ClaimType < ApplicationRecord
end
