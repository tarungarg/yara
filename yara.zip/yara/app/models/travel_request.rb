class TravelRequest < ApplicationRecord
  belongs_to :employee
  belongs_to :travel_type
  belongs_to :role
  belongs_to :attachment
end
