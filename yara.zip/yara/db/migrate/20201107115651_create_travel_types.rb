class CreateTravelTypes < ActiveRecord::Migration[6.0]
  def change
    create_table :travel_types do |t|
      t.string :travel_type
      t.references :role, null: false, foreign_key: true

      t.timestamps
    end
  end
end
