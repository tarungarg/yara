class SapApproval < ApplicationRecord
  belongs_to :approval_id, class_name: 'Employee', foreign_key: 'employee_id'
  belongs_to :sap_master
end
