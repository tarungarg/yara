# This file is auto-generated from the current state of the database. Instead
# of editing this file, please use the migrations feature of Active Record to
# incrementally modify your database, and then regenerate this schema definition.
#
# This file is the source Rails uses to define your schema when running `rails
# db:schema:load`. When creating a new database, `rails db:schema:load` tends to
# be faster and is potentially less error prone than running all of your
# migrations from scratch. Old migrations may fail to apply correctly if those
# migrations use external dependencies or application code.
#
# It's strongly recommended that you check this file into your version control system.

ActiveRecord::Schema.define(version: 2020_11_07_140121) do

  create_table "action_items", force: :cascade do |t|
    t.string "action_item_name"
    t.integer "meeting_id", null: false
    t.string "meeting_link"
    t.integer "assigned_to_id", null: false
    t.integer "group_id", null: false
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
    t.index ["assigned_to_id"], name: "index_action_items_on_assigned_to_id"
    t.index ["group_id"], name: "index_action_items_on_group_id"
    t.index ["meeting_id"], name: "index_action_items_on_meeting_id"
  end

  create_table "asset_employees", force: :cascade do |t|
    t.integer "employee_id", null: false
    t.integer "asset_id", null: false
    t.integer "assigned_by_id", null: false
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
    t.index ["asset_id"], name: "index_asset_employees_on_asset_id"
    t.index ["assigned_by_id"], name: "index_asset_employees_on_assigned_by_id"
    t.index ["employee_id"], name: "index_asset_employees_on_employee_id"
  end

  create_table "assets", force: :cascade do |t|
    t.integer "employee_id", null: false
    t.integer "department_id", null: false
    t.string "item"
    t.integer "assigned_by_id", null: false
    t.integer "qty"
    t.integer "threshhold"
    t.text "item_details"
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
    t.index ["assigned_by_id"], name: "index_assets_on_assigned_by_id"
    t.index ["department_id"], name: "index_assets_on_department_id"
    t.index ["employee_id"], name: "index_assets_on_employee_id"
  end

  create_table "attachments", force: :cascade do |t|
    t.string "url"
    t.string "type"
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
  end

  create_table "claim_approvers", force: :cascade do |t|
    t.integer "department_role_id_id", null: false
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
    t.index ["department_role_id_id"], name: "index_claim_approvers_on_department_role_id_id"
  end

  create_table "claim_types", force: :cascade do |t|
    t.string "claim_name"
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
  end

  create_table "cms", force: :cascade do |t|
    t.integer "claim_type_id_id", null: false
    t.integer "status"
    t.integer "claim_approvers_id_id", null: false
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
    t.index ["claim_approvers_id_id"], name: "index_cms_on_claim_approvers_id_id"
    t.index ["claim_type_id_id"], name: "index_cms_on_claim_type_id_id"
  end

  create_table "company_addresses", force: :cascade do |t|
    t.string "address"
    t.string "building_name"
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
  end

  create_table "complaint_types", force: :cascade do |t|
    t.integer "role_id", null: false
    t.string "complaint_type"
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
    t.index ["role_id"], name: "index_complaint_types_on_role_id"
  end

  create_table "complaints", force: :cascade do |t|
    t.text "desc"
    t.integer "employee_id", null: false
    t.integer "complaint_type_id", null: false
    t.integer "approver_id_id", null: false
    t.integer "attachment_id", null: false
    t.integer "status"
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
    t.index ["approver_id_id"], name: "index_complaints_on_approver_id_id"
    t.index ["attachment_id"], name: "index_complaints_on_attachment_id"
    t.index ["complaint_type_id"], name: "index_complaints_on_complaint_type_id"
    t.index ["employee_id"], name: "index_complaints_on_employee_id"
  end

  create_table "complaints_replies", force: :cascade do |t|
    t.text "reply"
    t.integer "employee_id", null: false
    t.integer "complaint_id", null: false
    t.integer "attachment_id", null: false
    t.integer "replyEmployeeId_id", null: false
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
    t.index ["attachment_id"], name: "index_complaints_replies_on_attachment_id"
    t.index ["complaint_id"], name: "index_complaints_replies_on_complaint_id"
    t.index ["employee_id"], name: "index_complaints_replies_on_employee_id"
    t.index ["replyEmployeeId_id"], name: "index_complaints_replies_on_replyEmployeeId_id"
  end

  create_table "department_roles", force: :cascade do |t|
    t.integer "role_id_id", null: false
    t.integer "department_id_id", null: false
    t.integer "rank"
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
    t.index ["department_id_id"], name: "index_department_roles_on_department_id_id"
    t.index ["role_id_id"], name: "index_department_roles_on_role_id_id"
  end

  create_table "departments", force: :cascade do |t|
    t.string "department_name"
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
  end

  create_table "employee_groups", force: :cascade do |t|
    t.integer "employee_id", null: false
    t.integer "group_id", null: false
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
    t.index ["employee_id"], name: "index_employee_groups_on_employee_id"
    t.index ["group_id"], name: "index_employee_groups_on_group_id"
  end

  create_table "employees", force: :cascade do |t|
    t.string "employee_name"
    t.integer "department_role_id_id", null: false
    t.string "emp_code"
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
    t.index ["department_role_id_id"], name: "index_employees_on_department_role_id_id"
  end

  create_table "groups", force: :cascade do |t|
    t.string "group_name"
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
  end

  create_table "leave_approvers", force: :cascade do |t|
    t.integer "leave_type_id_id"
    t.integer "leave_applied_by_id"
    t.text "leave_approvers"
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
    t.index ["leave_applied_by_id"], name: "index_leave_approvers_on_leave_applied_by_id"
    t.index ["leave_type_id_id"], name: "index_leave_approvers_on_leave_type_id_id"
  end

  create_table "leave_types", force: :cascade do |t|
    t.string "leave_name"
    t.integer "location_id_id", null: false
    t.boolean "auto_approve"
    t.integer "limits"
    t.boolean "docs_required"
    t.integer "leaves_per_month"
    t.text "leave_disabled"
    t.text "holiday_days"
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
    t.index ["location_id_id"], name: "index_leave_types_on_location_id_id"
  end

  create_table "lms", force: :cascade do |t|
    t.boolean "status"
    t.integer "leave_type_id_id", null: false
    t.integer "leave_approver_id_id", null: false
    t.integer "attachment_id_id", null: false
    t.integer "employee_id_id", null: false
    t.text "reason"
    t.text "reason_by_approver"
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
    t.index ["attachment_id_id"], name: "index_lms_on_attachment_id_id"
    t.index ["employee_id_id"], name: "index_lms_on_employee_id_id"
    t.index ["leave_approver_id_id"], name: "index_lms_on_leave_approver_id_id"
    t.index ["leave_type_id_id"], name: "index_lms_on_leave_type_id_id"
  end

  create_table "meetings", force: :cascade do |t|
    t.string "meeting_name"
    t.text "invites"
    t.string "meeting_link"
    t.text "accepted"
    t.text "rejected"
    t.text "mom"
    t.text "desc"
    t.integer "company_address_id", null: false
    t.integer "admin_id_id", null: false
    t.integer "room_time_slot_id", null: false
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
    t.index ["admin_id_id"], name: "index_meetings_on_admin_id_id"
    t.index ["company_address_id"], name: "index_meetings_on_company_address_id"
    t.index ["room_time_slot_id"], name: "index_meetings_on_room_time_slot_id"
  end

  create_table "po_pr_approvals", force: :cascade do |t|
    t.integer "approved_id_id", null: false
    t.integer "status"
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
    t.index ["approved_id_id"], name: "index_po_pr_approvals_on_approved_id_id"
  end

  create_table "roles", force: :cascade do |t|
    t.string "role_name"
    t.string "email"
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
  end

  create_table "room_time_slots", force: :cascade do |t|
    t.string "from"
    t.string "to"
    t.integer "room_id", null: false
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
    t.index ["room_id"], name: "index_room_time_slots_on_room_id"
  end

  create_table "rooms", force: :cascade do |t|
    t.string "name"
    t.integer "company_address_id", null: false
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
    t.index ["company_address_id"], name: "index_rooms_on_company_address_id"
  end

  create_table "sap_approvals", force: :cascade do |t|
    t.integer "approval_id_id", null: false
    t.integer "sap_master_id", null: false
    t.integer "rank"
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
    t.index ["approval_id_id"], name: "index_sap_approvals_on_approval_id_id"
    t.index ["sap_master_id"], name: "index_sap_approvals_on_sap_master_id"
  end

  create_table "sap_maters", force: :cascade do |t|
    t.integer "approved_id_id", null: false
    t.integer "status"
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
    t.index ["approved_id_id"], name: "index_sap_maters_on_approved_id_id"
  end

  create_table "suggestion_approvals", force: :cascade do |t|
    t.integer "role_id", null: false
    t.integer "rank"
    t.integer "suggestion_approval_id_id", null: false
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
    t.index ["role_id"], name: "index_suggestion_approvals_on_role_id"
    t.index ["suggestion_approval_id_id"], name: "index_suggestion_approvals_on_suggestion_approval_id_id"
  end

  create_table "suggestion_types", force: :cascade do |t|
    t.string "suggestion_type"
    t.string "reward_type"
    t.integer "reward_amount"
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
  end

  create_table "suggestions", force: :cascade do |t|
    t.text "desc"
    t.integer "suggestion_type_id", null: false
    t.integer "approved_id_id", null: false
    t.integer "attachment_id", null: false
    t.integer "status"
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
    t.index ["approved_id_id"], name: "index_suggestions_on_approved_id_id"
    t.index ["attachment_id"], name: "index_suggestions_on_attachment_id"
    t.index ["suggestion_type_id"], name: "index_suggestions_on_suggestion_type_id"
  end

  create_table "timesheets", force: :cascade do |t|
    t.text "details"
    t.integer "employee_id", null: false
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
    t.index ["employee_id"], name: "index_timesheets_on_employee_id"
  end

  create_table "travel_requests", force: :cascade do |t|
    t.text "desc"
    t.integer "employee_id", null: false
    t.integer "travel_type_id", null: false
    t.integer "approval_id_id", null: false
    t.integer "attachment_id", null: false
    t.integer "status"
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
    t.index ["approval_id_id"], name: "index_travel_requests_on_approval_id_id"
    t.index ["attachment_id"], name: "index_travel_requests_on_attachment_id"
    t.index ["employee_id"], name: "index_travel_requests_on_employee_id"
    t.index ["travel_type_id"], name: "index_travel_requests_on_travel_type_id"
  end

  create_table "travel_types", force: :cascade do |t|
    t.string "travel_type"
    t.integer "role_id", null: false
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
    t.index ["role_id"], name: "index_travel_types_on_role_id"
  end

  add_foreign_key "action_items", "assigned_tos"
  add_foreign_key "action_items", "groups"
  add_foreign_key "action_items", "meetings"
  add_foreign_key "asset_employees", "assets"
  add_foreign_key "asset_employees", "assigned_bies"
  add_foreign_key "asset_employees", "employees"
  add_foreign_key "assets", "assigned_bies"
  add_foreign_key "assets", "departments"
  add_foreign_key "assets", "employees"
  add_foreign_key "claim_approvers", "department_role_ids"
  add_foreign_key "cms", "claim_approvers_ids"
  add_foreign_key "cms", "claim_type_ids"
  add_foreign_key "complaint_types", "roles"
  add_foreign_key "complaints", "approver_ids"
  add_foreign_key "complaints", "attachments"
  add_foreign_key "complaints", "complaint_types"
  add_foreign_key "complaints", "employees"
  add_foreign_key "complaints_replies", "attachments"
  add_foreign_key "complaints_replies", "complaints"
  add_foreign_key "complaints_replies", "employees"
  add_foreign_key "complaints_replies", "replyEmployeeIds"
  add_foreign_key "department_roles", "department_ids"
  add_foreign_key "department_roles", "role_ids"
  add_foreign_key "employee_groups", "employees"
  add_foreign_key "employee_groups", "groups"
  add_foreign_key "employees", "department_role_ids"
  add_foreign_key "leave_types", "location_ids"
  add_foreign_key "lms", "attachment_ids"
  add_foreign_key "lms", "employee_ids"
  add_foreign_key "lms", "leave_approver_ids"
  add_foreign_key "lms", "leave_type_ids"
  add_foreign_key "meetings", "admin_ids"
  add_foreign_key "meetings", "company_addresses"
  add_foreign_key "meetings", "room_time_slots"
  add_foreign_key "po_pr_approvals", "approved_ids"
  add_foreign_key "room_time_slots", "rooms"
  add_foreign_key "rooms", "company_addresses"
  add_foreign_key "sap_approvals", "approval_ids"
  add_foreign_key "sap_approvals", "sap_masters"
  add_foreign_key "sap_maters", "approved_ids"
  add_foreign_key "suggestion_approvals", "roles"
  add_foreign_key "suggestion_approvals", "suggestion_approval_ids"
  add_foreign_key "suggestions", "approved_ids"
  add_foreign_key "suggestions", "attachments"
  add_foreign_key "suggestions", "suggestion_types"
  add_foreign_key "timesheets", "employees"
  add_foreign_key "travel_requests", "approval_ids"
  add_foreign_key "travel_requests", "attachments"
  add_foreign_key "travel_requests", "employees"
  add_foreign_key "travel_requests", "travel_types"
  add_foreign_key "travel_types", "roles"
end
