class CreateEmployees < ActiveRecord::Migration[6.0]
  def change
    create_table :employees do |t|
      t.string :employee_name
      t.references :department_role_id, null: false, foreign_key: true
      t.string :emp_code

      t.timestamps
    end
  end
end
