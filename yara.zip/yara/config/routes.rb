Rails.application.routes.draw do
  namespace :admin do
    resources :po_pr_approvals
    resources :sap_approvals
    resources :sap_maters
    resources :suggestion_approvals
    resources :suggestion_types
    resources :rooms
    resources :assets
    resources :complaint_types
    resources :employees
    resources :leave_approvers
    resources :leave_types
    resources :company_addresses
    resources :departments
    resources :roles
    resources :claim_approvers
    resources :claim_types
    resources :travel_types
    resources :asset_employees
  end
  namespace :api do
    namespace :v1 do
      resources :suggestions
      resources :meetings do
        resources :action_items
      end
      resources :complaints do
        resources :complaints_replies
      end
      resources :cms
      resources :lms
      resources :timesheets
      resources :travel_requests
      resources :groups do
        post :add_employee
      end
    end
  end
end
