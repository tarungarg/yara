module API
  class V1::LmsController < ApplicationController
    before_action :set_lm, only: [:show, :edit, :update, :destroy]

    # GET /lms
    # GET /lms.json
    def index
      @lms = Lms.all
    end

    # GET /lms/1
    # GET /lms/1.json
    def show
    end

    # GET /lms/new
    def new
      @lm = Lms.new
    end

    # GET /lms/1/edit
    def edit
    end

    # POST /lms
    # POST /lms.json
    def create
      @lm = Lms.new(lm_params)

      respond_to do |format|
        if @lm.save
          format.html { redirect_to @lm, notice: 'Lms was successfully created.' }
          format.json { render :show, status: :created, location: @lm }
        else
          format.html { render :new }
          format.json { render json: @lm.errors, status: :unprocessable_entity }
        end
      end
    end

    # PATCH/PUT /lms/1
    # PATCH/PUT /lms/1.json
    def update
      respond_to do |format|
        if @lm.update(lm_params)
          format.html { redirect_to @lm, notice: 'Lms was successfully updated.' }
          format.json { render :show, status: :ok, location: @lm }
        else
          format.html { render :edit }
          format.json { render json: @lm.errors, status: :unprocessable_entity }
        end
      end
    end

    # DELETE /lms/1
    # DELETE /lms/1.json
    def destroy
      @lm.destroy
      respond_to do |format|
        format.html { redirect_to lms_index_url, notice: 'Lms was successfully destroyed.' }
        format.json { head :no_content }
      end
    end

    private
      # Use callbacks to share common setup or constraints between actions.
      def set_lm
        @lm = Lms.find(params[:id])
      end

      # Only allow a list of trusted parameters through.
      def lm_params
        params.require(:lm).permit(:status, :leave_type_id_id, :leave_approver_id_id, :attachment_id_id, :employee_id_id, :reason, :reason_by_approver)
      end
  end
end
