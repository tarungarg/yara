module Admin::ComplaintTypesHelper
end
