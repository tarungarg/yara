require 'test_helper'

class ComplaintsRepliesControllerTest < ActionDispatch::IntegrationTest
  setup do
    @complaints_reply = complaints_replies(:one)
  end

  test "should get index" do
    get complaints_replies_url
    assert_response :success
  end

  test "should get new" do
    get new_complaints_reply_url
    assert_response :success
  end

  test "should create complaints_reply" do
    assert_difference('ComplaintsReply.count') do
      post complaints_replies_url, params: { complaints_reply: { attachment_id: @complaints_reply.attachment_id, complaint_id: @complaints_reply.complaint_id, employee_id: @complaints_reply.employee_id, reply: @complaints_reply.reply, replyEmployeeId_id: @complaints_reply.replyEmployeeId_id } }
    end

    assert_redirected_to complaints_reply_url(ComplaintsReply.last)
  end

  test "should show complaints_reply" do
    get complaints_reply_url(@complaints_reply)
    assert_response :success
  end

  test "should get edit" do
    get edit_complaints_reply_url(@complaints_reply)
    assert_response :success
  end

  test "should update complaints_reply" do
    patch complaints_reply_url(@complaints_reply), params: { complaints_reply: { attachment_id: @complaints_reply.attachment_id, complaint_id: @complaints_reply.complaint_id, employee_id: @complaints_reply.employee_id, reply: @complaints_reply.reply, replyEmployeeId_id: @complaints_reply.replyEmployeeId_id } }
    assert_redirected_to complaints_reply_url(@complaints_reply)
  end

  test "should destroy complaints_reply" do
    assert_difference('ComplaintsReply.count', -1) do
      delete complaints_reply_url(@complaints_reply)
    end

    assert_redirected_to complaints_replies_url
  end
end
