require 'test_helper'

class CompanyAddressTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
