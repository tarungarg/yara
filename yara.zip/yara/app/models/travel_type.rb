class TravelType < ApplicationRecord
  belongs_to :role
end
