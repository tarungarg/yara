class  Admin::SapApprovalsController < ApplicationController
  before_action :set_sap_approval, only: [:show, :edit, :update, :destroy]

  # GET /sap_approvals
  # GET /sap_approvals.json
  def index
    @sap_approvals = SapApproval.all
  end

  # GET /sap_approvals/1
  # GET /sap_approvals/1.json
  def show
  end

  # GET /sap_approvals/new
  def new
    @sap_approval = SapApproval.new
  end

  # GET /sap_approvals/1/edit
  def edit
  end

  # POST /sap_approvals
  # POST /sap_approvals.json
  def create
    @sap_approval = SapApproval.new(sap_approval_params)

    respond_to do |format|
      if @sap_approval.save
        format.html { redirect_to @sap_approval, notice: 'Sap approval was successfully created.' }
        format.json { render :show, status: :created, location: @sap_approval }
      else
        format.html { render :new }
        format.json { render json: @sap_approval.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /sap_approvals/1
  # PATCH/PUT /sap_approvals/1.json
  def update
    respond_to do |format|
      if @sap_approval.update(sap_approval_params)
        format.html { redirect_to @sap_approval, notice: 'Sap approval was successfully updated.' }
        format.json { render :show, status: :ok, location: @sap_approval }
      else
        format.html { render :edit }
        format.json { render json: @sap_approval.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /sap_approvals/1
  # DELETE /sap_approvals/1.json
  def destroy
    @sap_approval.destroy
    respond_to do |format|
      format.html { redirect_to sap_approvals_url, notice: 'Sap approval was successfully destroyed.' }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_sap_approval
      @sap_approval = SapApproval.find(params[:id])
    end

    # Only allow a list of trusted parameters through.
    def sap_approval_params
      params.require(:sap_approval).permit(:approval_id_id, :sap_master_id, :rank)
    end
end
