require 'test_helper'

class LeaveApproversControllerTest < ActionDispatch::IntegrationTest
  setup do
    @leave_approver = leave_approvers(:one)
  end

  test "should get index" do
    get leave_approvers_url
    assert_response :success
  end

  test "should get new" do
    get new_leave_approver_url
    assert_response :success
  end

  test "should create leave_approver" do
    assert_difference('LeaveApprover.count') do
      post leave_approvers_url, params: { leave_approver: { leave_applied_by: @leave_approver.leave_applied_by, leave_approvers: @leave_approver.leave_approvers, leave_type_id: @leave_approver.leave_type_id } }
    end

    assert_redirected_to leave_approver_url(LeaveApprover.last)
  end

  test "should show leave_approver" do
    get leave_approver_url(@leave_approver)
    assert_response :success
  end

  test "should get edit" do
    get edit_leave_approver_url(@leave_approver)
    assert_response :success
  end

  test "should update leave_approver" do
    patch leave_approver_url(@leave_approver), params: { leave_approver: { leave_applied_by: @leave_approver.leave_applied_by, leave_approvers: @leave_approver.leave_approvers, leave_type_id: @leave_approver.leave_type_id } }
    assert_redirected_to leave_approver_url(@leave_approver)
  end

  test "should destroy leave_approver" do
    assert_difference('LeaveApprover.count', -1) do
      delete leave_approver_url(@leave_approver)
    end

    assert_redirected_to leave_approvers_url
  end
end
