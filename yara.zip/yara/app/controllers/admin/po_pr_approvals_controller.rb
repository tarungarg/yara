class Admin::PoPrApprovalsController < ApplicationController
  before_action :set_po_pr_approval, only: [:show, :edit, :update, :destroy]

  # GET /po_pr_approvals
  # GET /po_pr_approvals.json
  def index
    @po_pr_approvals = PoPrApproval.all
  end

  # GET /po_pr_approvals/1
  # GET /po_pr_approvals/1.json
  def show
  end

  # GET /po_pr_approvals/new
  def new
    @po_pr_approval = PoPrApproval.new
  end

  # GET /po_pr_approvals/1/edit
  def edit
  end

  # POST /po_pr_approvals
  # POST /po_pr_approvals.json
  def create
    @po_pr_approval = PoPrApproval.new(po_pr_approval_params)

    respond_to do |format|
      if @po_pr_approval.save
        format.html { redirect_to @po_pr_approval, notice: 'Po pr approval was successfully created.' }
        format.json { render :show, status: :created, location: @po_pr_approval }
      else
        format.html { render :new }
        format.json { render json: @po_pr_approval.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /po_pr_approvals/1
  # PATCH/PUT /po_pr_approvals/1.json
  def update
    respond_to do |format|
      if @po_pr_approval.update(po_pr_approval_params)
        format.html { redirect_to @po_pr_approval, notice: 'Po pr approval was successfully updated.' }
        format.json { render :show, status: :ok, location: @po_pr_approval }
      else
        format.html { render :edit }
        format.json { render json: @po_pr_approval.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /po_pr_approvals/1
  # DELETE /po_pr_approvals/1.json
  def destroy
    @po_pr_approval.destroy
    respond_to do |format|
      format.html { redirect_to po_pr_approvals_url, notice: 'Po pr approval was successfully destroyed.' }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_po_pr_approval
      @po_pr_approval = PoPrApproval.find(params[:id])
    end

    # Only allow a list of trusted parameters through.
    def po_pr_approval_params
      params.require(:po_pr_approval).permit(:approved_id_id, :status)
    end
end
