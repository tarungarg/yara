class CreateTravelRequests < ActiveRecord::Migration[6.0]
  def change
    create_table :travel_requests do |t|
      t.text :desc
      t.references :employee, null: false, foreign_key: true
      t.references :travel_type, null: false, foreign_key: true
      t.references :approval_id, null: false, foreign_key: true
      t.references :attachment, null: false, foreign_key: true
      t.integer :status

      t.timestamps
    end
  end
end
