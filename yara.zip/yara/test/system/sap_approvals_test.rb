require "application_system_test_case"

class SapApprovalsTest < ApplicationSystemTestCase
  setup do
    @sap_approval = sap_approvals(:one)
  end

  test "visiting the index" do
    visit sap_approvals_url
    assert_selector "h1", text: "Sap Approvals"
  end

  test "creating a Sap approval" do
    visit sap_approvals_url
    click_on "New Sap Approval"

    fill_in "Approval id", with: @sap_approval.approval_id_id
    fill_in "Rank", with: @sap_approval.rank
    fill_in "Sap master", with: @sap_approval.sap_master_id
    click_on "Create Sap approval"

    assert_text "Sap approval was successfully created"
    click_on "Back"
  end

  test "updating a Sap approval" do
    visit sap_approvals_url
    click_on "Edit", match: :first

    fill_in "Approval id", with: @sap_approval.approval_id_id
    fill_in "Rank", with: @sap_approval.rank
    fill_in "Sap master", with: @sap_approval.sap_master_id
    click_on "Update Sap approval"

    assert_text "Sap approval was successfully updated"
    click_on "Back"
  end

  test "destroying a Sap approval" do
    visit sap_approvals_url
    page.accept_confirm do
      click_on "Destroy", match: :first
    end

    assert_text "Sap approval was successfully destroyed"
  end
end
