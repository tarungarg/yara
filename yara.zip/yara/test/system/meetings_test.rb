require "application_system_test_case"

class MeetingsTest < ApplicationSystemTestCase
  setup do
    @meeting = meetings(:one)
  end

  test "visiting the index" do
    visit meetings_url
    assert_selector "h1", text: "Meetings"
  end

  test "creating a Meeting" do
    visit meetings_url
    click_on "New Meeting"

    fill_in "Accepted", with: @meeting.accepted
    fill_in "Admin id", with: @meeting.admin_id_id
    fill_in "Company address", with: @meeting.company_address_id
    fill_in "Desc", with: @meeting.desc
    fill_in "Invites", with: @meeting.invites
    fill_in "Meeting link", with: @meeting.meeting_link
    fill_in "Meeting name", with: @meeting.meeting_name
    fill_in "Mom", with: @meeting.mom
    fill_in "Rejected", with: @meeting.rejected
    fill_in "Room time slot", with: @meeting.room_time_slot_id
    click_on "Create Meeting"

    assert_text "Meeting was successfully created"
    click_on "Back"
  end

  test "updating a Meeting" do
    visit meetings_url
    click_on "Edit", match: :first

    fill_in "Accepted", with: @meeting.accepted
    fill_in "Admin id", with: @meeting.admin_id_id
    fill_in "Company address", with: @meeting.company_address_id
    fill_in "Desc", with: @meeting.desc
    fill_in "Invites", with: @meeting.invites
    fill_in "Meeting link", with: @meeting.meeting_link
    fill_in "Meeting name", with: @meeting.meeting_name
    fill_in "Mom", with: @meeting.mom
    fill_in "Rejected", with: @meeting.rejected
    fill_in "Room time slot", with: @meeting.room_time_slot_id
    click_on "Update Meeting"

    assert_text "Meeting was successfully updated"
    click_on "Back"
  end

  test "destroying a Meeting" do
    visit meetings_url
    page.accept_confirm do
      click_on "Destroy", match: :first
    end

    assert_text "Meeting was successfully destroyed"
  end
end
