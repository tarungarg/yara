require "application_system_test_case"

class ClaimTypesTest < ApplicationSystemTestCase
  setup do
    @claim_type = claim_types(:one)
  end

  test "visiting the index" do
    visit claim_types_url
    assert_selector "h1", text: "Claim Types"
  end

  test "creating a Claim type" do
    visit claim_types_url
    click_on "New Claim Type"

    fill_in "Claim name", with: @claim_type.claim_name
    click_on "Create Claim type"

    assert_text "Claim type was successfully created"
    click_on "Back"
  end

  test "updating a Claim type" do
    visit claim_types_url
    click_on "Edit", match: :first

    fill_in "Claim name", with: @claim_type.claim_name
    click_on "Update Claim type"

    assert_text "Claim type was successfully updated"
    click_on "Back"
  end

  test "destroying a Claim type" do
    visit claim_types_url
    page.accept_confirm do
      click_on "Destroy", match: :first
    end

    assert_text "Claim type was successfully destroyed"
  end
end
