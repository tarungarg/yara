class CreateSuggestions < ActiveRecord::Migration[6.0]
  def change
    create_table :suggestions do |t|
      t.text :desc
      t.references :suggestion_type, null: false, foreign_key: true
      t.references :approved_id, null: false, foreign_key: true
      t.references :attachment, null: false, foreign_key: true
      t.integer :status

      t.timestamps
    end
  end
end
