class Cms < ApplicationRecord
  belongs_to :claim_type
  belongs_to :claim_approvers
end
