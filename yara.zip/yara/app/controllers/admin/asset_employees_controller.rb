class Admin::AssetEmployeesController < ApplicationController
  before_action :set_asset_employee, only: [:show, :edit, :update, :destroy]

  # GET /asset_employees
  # GET /asset_employees.json
  def index
    @asset_employees = AssetEmployee.all
  end

  # GET /asset_employees/1
  # GET /asset_employees/1.json
  def show
  end

  # GET /asset_employees/new
  def new
    @asset_employee = AssetEmployee.new
  end

  # GET /asset_employees/1/edit
  def edit
  end

  # POST /asset_employees
  # POST /asset_employees.json
  def create
    @asset_employee = AssetEmployee.new(asset_employee_params)

    respond_to do |format|
      if @asset_employee.save
        format.html { redirect_to @asset_employee, notice: 'Asset employee was successfully created.' }
        format.json { render :show, status: :created, location: @asset_employee }
      else
        format.html { render :new }
        format.json { render json: @asset_employee.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /asset_employees/1
  # PATCH/PUT /asset_employees/1.json
  def update
    respond_to do |format|
      if @asset_employee.update(asset_employee_params)
        format.html { redirect_to @asset_employee, notice: 'Asset employee was successfully updated.' }
        format.json { render :show, status: :ok, location: @asset_employee }
      else
        format.html { render :edit }
        format.json { render json: @asset_employee.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /asset_employees/1
  # DELETE /asset_employees/1.json
  def destroy
    @asset_employee.destroy
    respond_to do |format|
      format.html { redirect_to asset_employees_url, notice: 'Asset employee was successfully destroyed.' }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_asset_employee
      @asset_employee = AssetEmployee.find(params[:id])
    end

    # Only allow a list of trusted parameters through.
    def asset_employee_params
      params.require(:asset_employee).permit(:employee_id, :asset_id, :assigned_by_id)
    end
end
