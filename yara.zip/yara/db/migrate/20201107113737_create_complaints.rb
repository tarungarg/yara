class CreateComplaints < ActiveRecord::Migration[6.0]
  def change
    create_table :complaints do |t|
      t.text :desc
      t.references :employee, null: false, foreign_key: true
      t.references :complaint_type, null: false, foreign_key: true
      t.references :approver_id, null: false, foreign_key: true
      t.references :attachment, null: false, foreign_key: true
      t.integer :status

      t.timestamps
    end
  end
end
