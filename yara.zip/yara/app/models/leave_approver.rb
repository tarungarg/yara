class LeaveApprover < ApplicationRecord
end
