module API
  class V1::CmsController < ApplicationController
    before_action :set_cm, only: [:show, :edit, :update, :destroy]

    # GET /cms
    # GET /cms.json
    def index
      @cms = Cms.all
    end

    # GET /cms/1
    # GET /cms/1.json
    def show
    end

    # GET /cms/new
    def new
      @cm = Cms.new
    end

    # GET /cms/1/edit
    def edit
    end

    # POST /cms
    # POST /cms.json
    def create
      @cm = Cms.new(cm_params)

      respond_to do |format|
        if @cms.save
          format.html { redirect_to @cm, notice: 'Cm was successfully created.' }
          format.json { render :show, status: :created, location: @cm }
        else
          format.html { render :new }
          format.json { render json: @cms.errors, status: :unprocessable_entity }
        end
      end
    end

    # PATCH/PUT /cms/1
    # PATCH/PUT /cms/1.json
    def update
      respond_to do |format|
        if @cms.update(cm_params)
          format.html { redirect_to @cm, notice: 'Cm was successfully updated.' }
          format.json { render :show, status: :ok, location: @cm }
        else
          format.html { render :edit }
          format.json { render json: @cms.errors, status: :unprocessable_entity }
        end
      end
    end

    # DELETE /cms/1
    # DELETE /cms/1.json
    def destroy
      @cms.destroy
      respond_to do |format|
        format.html { redirect_to cms_url, notice: 'Cm was successfully destroyed.' }
        format.json { head :no_content }
      end
    end

    private
      # Use callbacks to share common setup or constraints between actions.
      def set_cm
        @cm = Cms.find(params[:id])
      end

      # Only allow a list of trusted parameters through.
      def cm_params
        params.require(:cm).permit(:claim_type_id_id, :status, :claim_approvers_id_id)
      end
  end
end
