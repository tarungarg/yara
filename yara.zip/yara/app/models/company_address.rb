class CompanyAddress < ApplicationRecord
end
