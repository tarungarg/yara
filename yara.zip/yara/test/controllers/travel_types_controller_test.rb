require 'test_helper'

class TravelTypesControllerTest < ActionDispatch::IntegrationTest
  setup do
    @travel_type = travel_types(:one)
  end

  test "should get index" do
    get travel_types_url
    assert_response :success
  end

  test "should get new" do
    get new_travel_type_url
    assert_response :success
  end

  test "should create travel_type" do
    assert_difference('TravelType.count') do
      post travel_types_url, params: { travel_type: { role_id: @travel_type.role_id, travel_type: @travel_type.travel_type } }
    end

    assert_redirected_to travel_type_url(TravelType.last)
  end

  test "should show travel_type" do
    get travel_type_url(@travel_type)
    assert_response :success
  end

  test "should get edit" do
    get edit_travel_type_url(@travel_type)
    assert_response :success
  end

  test "should update travel_type" do
    patch travel_type_url(@travel_type), params: { travel_type: { role_id: @travel_type.role_id, travel_type: @travel_type.travel_type } }
    assert_redirected_to travel_type_url(@travel_type)
  end

  test "should destroy travel_type" do
    assert_difference('TravelType.count', -1) do
      delete travel_type_url(@travel_type)
    end

    assert_redirected_to travel_types_url
  end
end
