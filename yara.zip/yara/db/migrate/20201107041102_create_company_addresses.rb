class CreateCompanyAddresses < ActiveRecord::Migration[6.0]
  def change
    create_table :company_addresses do |t|
      t.string :address
      t.string :building_name

      t.timestamps
    end
  end
end
