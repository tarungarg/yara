class Admin::ClaimApproversController < ApplicationController
  before_action :set_claim_approver, only: [:show, :edit, :update, :destroy]

  # GET /claim_approvers
  # GET /claim_approvers.json
  def index
    @claim_approvers = ClaimApprover.all
  end

  # GET /claim_approvers/1
  # GET /claim_approvers/1.json
  def show
  end

  # GET /claim_approvers/new
  def new
    @claim_approver = ClaimApprover.new
  end

  # GET /claim_approvers/1/edit
  def edit
  end

  # POST /claim_approvers
  # POST /claim_approvers.json
  def create
    @claim_approver = ClaimApprover.new(claim_approver_params)

    respond_to do |format|
      if @claim_approver.save
        format.html { redirect_to @claim_approver, notice: 'Claim approver was successfully created.' }
        format.json { render :show, status: :created, location: @claim_approver }
      else
        format.html { render :new }
        format.json { render json: @claim_approver.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /claim_approvers/1
  # PATCH/PUT /claim_approvers/1.json
  def update
    respond_to do |format|
      if @claim_approver.update(claim_approver_params)
        format.html { redirect_to @claim_approver, notice: 'Claim approver was successfully updated.' }
        format.json { render :show, status: :ok, location: @claim_approver }
      else
        format.html { render :edit }
        format.json { render json: @claim_approver.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /claim_approvers/1
  # DELETE /claim_approvers/1.json
  def destroy
    @claim_approver.destroy
    respond_to do |format|
      format.html { redirect_to claim_approvers_url, notice: 'Claim approver was successfully destroyed.' }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_claim_approver
      @claim_approver = ClaimApprover.find(params[:id])
    end

    # Only allow a list of trusted parameters through.
    def claim_approver_params
      params.require(:claim_approver).permit(:department_role_id_id)
    end
end
