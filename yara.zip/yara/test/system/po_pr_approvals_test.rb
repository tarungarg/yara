require "application_system_test_case"

class PoPrApprovalsTest < ApplicationSystemTestCase
  setup do
    @po_pr_approval = po_pr_approvals(:one)
  end

  test "visiting the index" do
    visit po_pr_approvals_url
    assert_selector "h1", text: "Po Pr Approvals"
  end

  test "creating a Po pr approval" do
    visit po_pr_approvals_url
    click_on "New Po Pr Approval"

    fill_in "Approved id", with: @po_pr_approval.approved_id_id
    fill_in "Status", with: @po_pr_approval.status
    click_on "Create Po pr approval"

    assert_text "Po pr approval was successfully created"
    click_on "Back"
  end

  test "updating a Po pr approval" do
    visit po_pr_approvals_url
    click_on "Edit", match: :first

    fill_in "Approved id", with: @po_pr_approval.approved_id_id
    fill_in "Status", with: @po_pr_approval.status
    click_on "Update Po pr approval"

    assert_text "Po pr approval was successfully updated"
    click_on "Back"
  end

  test "destroying a Po pr approval" do
    visit po_pr_approvals_url
    page.accept_confirm do
      click_on "Destroy", match: :first
    end

    assert_text "Po pr approval was successfully destroyed"
  end
end
