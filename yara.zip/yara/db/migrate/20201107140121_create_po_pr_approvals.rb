class CreatePoPrApprovals < ActiveRecord::Migration[6.0]
  def change
    create_table :po_pr_approvals do |t|
      t.references :approved_id, null: false, foreign_key: true
      t.integer :status

      t.timestamps
    end
  end
end
