class Admin::TravelTypesController < ApplicationController
  before_action :set_travel_type, only: [:show, :edit, :update, :destroy]

  # GET /travel_types
  # GET /travel_types.json
  def index
    @travel_types = TravelType.all
  end

  # GET /travel_types/1
  # GET /travel_types/1.json
  def show
  end

  # GET /travel_types/new
  def new
    @travel_type = TravelType.new
  end

  # GET /travel_types/1/edit
  def edit
  end

  # POST /travel_types
  # POST /travel_types.json
  def create
    @travel_type = TravelType.new(travel_type_params)

    respond_to do |format|
      if @travel_type.save
        format.html { redirect_to @travel_type, notice: 'Travel type was successfully created.' }
        format.json { render :show, status: :created, location: @travel_type }
      else
        format.html { render :new }
        format.json { render json: @travel_type.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /travel_types/1
  # PATCH/PUT /travel_types/1.json
  def update
    respond_to do |format|
      if @travel_type.update(travel_type_params)
        format.html { redirect_to @travel_type, notice: 'Travel type was successfully updated.' }
        format.json { render :show, status: :ok, location: @travel_type }
      else
        format.html { render :edit }
        format.json { render json: @travel_type.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /travel_types/1
  # DELETE /travel_types/1.json
  def destroy
    @travel_type.destroy
    respond_to do |format|
      format.html { redirect_to travel_types_url, notice: 'Travel type was successfully destroyed.' }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_travel_type
      @travel_type = TravelType.find(params[:id])
    end

    # Only allow a list of trusted parameters through.
    def travel_type_params
      params.require(:travel_type).permit(:travel_type, :role_id)
    end
end
