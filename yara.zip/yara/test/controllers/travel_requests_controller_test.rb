require 'test_helper'

class TravelRequestsControllerTest < ActionDispatch::IntegrationTest
  setup do
    @travel_request = travel_requests(:one)
  end

  test "should get index" do
    get travel_requests_url
    assert_response :success
  end

  test "should get new" do
    get new_travel_request_url
    assert_response :success
  end

  test "should create travel_request" do
    assert_difference('TravelRequest.count') do
      post travel_requests_url, params: { travel_request: { approval_id_id: @travel_request.approval_id_id, attachment_id: @travel_request.attachment_id, desc: @travel_request.desc, employee_id: @travel_request.employee_id, status: @travel_request.status, travel_type_id: @travel_request.travel_type_id } }
    end

    assert_redirected_to travel_request_url(TravelRequest.last)
  end

  test "should show travel_request" do
    get travel_request_url(@travel_request)
    assert_response :success
  end

  test "should get edit" do
    get edit_travel_request_url(@travel_request)
    assert_response :success
  end

  test "should update travel_request" do
    patch travel_request_url(@travel_request), params: { travel_request: { approval_id_id: @travel_request.approval_id_id, attachment_id: @travel_request.attachment_id, desc: @travel_request.desc, employee_id: @travel_request.employee_id, status: @travel_request.status, travel_type_id: @travel_request.travel_type_id } }
    assert_redirected_to travel_request_url(@travel_request)
  end

  test "should destroy travel_request" do
    assert_difference('TravelRequest.count', -1) do
      delete travel_request_url(@travel_request)
    end

    assert_redirected_to travel_requests_url
  end
end
