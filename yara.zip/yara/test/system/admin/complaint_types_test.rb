require "application_system_test_case"

class Admin::ComplaintTypesTest < ApplicationSystemTestCase
  setup do
    @admin_complaint_type = admin_complaint_types(:one)
  end

  test "visiting the index" do
    visit admin_complaint_types_url
    assert_selector "h1", text: "Admin/Complaint Types"
  end

  test "creating a Complaint type" do
    visit admin_complaint_types_url
    click_on "New Admin/Complaint Type"

    fill_in "Complaint type", with: @admin_complaint_type.complaint_type
    fill_in "Role", with: @admin_complaint_type.role_id
    click_on "Create Complaint type"

    assert_text "Complaint type was successfully created"
    click_on "Back"
  end

  test "updating a Complaint type" do
    visit admin_complaint_types_url
    click_on "Edit", match: :first

    fill_in "Complaint type", with: @admin_complaint_type.complaint_type
    fill_in "Role", with: @admin_complaint_type.role_id
    click_on "Update Complaint type"

    assert_text "Complaint type was successfully updated"
    click_on "Back"
  end

  test "destroying a Complaint type" do
    visit admin_complaint_types_url
    page.accept_confirm do
      click_on "Destroy", match: :first
    end

    assert_text "Complaint type was successfully destroyed"
  end
end
