class CreateDepartmentRoles < ActiveRecord::Migration[6.0]
  def change
    create_table :department_roles do |t|
      t.references :role_id, null: false, foreign_key: true
      t.references :department_id, null: false, foreign_key: true
      t.integer :rank

      t.timestamps
    end
  end
end
