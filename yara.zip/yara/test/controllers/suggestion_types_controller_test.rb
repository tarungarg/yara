require 'test_helper'

class SuggestionTypesControllerTest < ActionDispatch::IntegrationTest
  setup do
    @suggestion_type = suggestion_types(:one)
  end

  test "should get index" do
    get suggestion_types_url
    assert_response :success
  end

  test "should get new" do
    get new_suggestion_type_url
    assert_response :success
  end

  test "should create suggestion_type" do
    assert_difference('SuggestionType.count') do
      post suggestion_types_url, params: { suggestion_type: { reward_amount: @suggestion_type.reward_amount, reward_type: @suggestion_type.reward_type, suggestion_type: @suggestion_type.suggestion_type } }
    end

    assert_redirected_to suggestion_type_url(SuggestionType.last)
  end

  test "should show suggestion_type" do
    get suggestion_type_url(@suggestion_type)
    assert_response :success
  end

  test "should get edit" do
    get edit_suggestion_type_url(@suggestion_type)
    assert_response :success
  end

  test "should update suggestion_type" do
    patch suggestion_type_url(@suggestion_type), params: { suggestion_type: { reward_amount: @suggestion_type.reward_amount, reward_type: @suggestion_type.reward_type, suggestion_type: @suggestion_type.suggestion_type } }
    assert_redirected_to suggestion_type_url(@suggestion_type)
  end

  test "should destroy suggestion_type" do
    assert_difference('SuggestionType.count', -1) do
      delete suggestion_type_url(@suggestion_type)
    end

    assert_redirected_to suggestion_types_url
  end
end
