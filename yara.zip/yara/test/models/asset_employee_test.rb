require 'test_helper'

class AssetEmployeeTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
