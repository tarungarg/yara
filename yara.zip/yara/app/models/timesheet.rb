class Timesheet < ApplicationRecord
  belongs_to :employee
end
