class CreateSuggestionApprovals < ActiveRecord::Migration[6.0]
  def change
    create_table :suggestion_approvals do |t|
      t.references :role, null: false, foreign_key: true
      t.integer :rank
      t.references :suggestion_approval_id, null: false, foreign_key: true

      t.timestamps
    end
  end
end
