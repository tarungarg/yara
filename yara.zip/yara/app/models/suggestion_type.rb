class SuggestionType < ApplicationRecord
end
