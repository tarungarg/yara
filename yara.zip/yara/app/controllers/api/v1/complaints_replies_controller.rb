class API::V1::ComplaintsRepliesController < ApplicationController
  before_action :set_complaints_reply, only: [:show, :edit, :update, :destroy]

  # GET /complaints_replies
  # GET /complaints_replies.json
  def index
    @complaints_replies = ComplaintsReply.all
  end

  # GET /complaints_replies/1
  # GET /complaints_replies/1.json
  def show
  end

  # GET /complaints_replies/new
  def new
    @complaints_reply = ComplaintsReply.new
  end

  # GET /complaints_replies/1/edit
  def edit
  end

  # POST /complaints_replies
  # POST /complaints_replies.json
  def create
    @complaints_reply = ComplaintsReply.new(complaints_reply_params)

    respond_to do |format|
      if @complaints_reply.save
        format.html { redirect_to @complaints_reply, notice: 'Complaints reply was successfully created.' }
        format.json { render :show, status: :created, location: @complaints_reply }
      else
        format.html { render :new }
        format.json { render json: @complaints_reply.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /complaints_replies/1
  # PATCH/PUT /complaints_replies/1.json
  def update
    respond_to do |format|
      if @complaints_reply.update(complaints_reply_params)
        format.html { redirect_to @complaints_reply, notice: 'Complaints reply was successfully updated.' }
        format.json { render :show, status: :ok, location: @complaints_reply }
      else
        format.html { render :edit }
        format.json { render json: @complaints_reply.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /complaints_replies/1
  # DELETE /complaints_replies/1.json
  def destroy
    @complaints_reply.destroy
    respond_to do |format|
      format.html { redirect_to complaints_replies_url, notice: 'Complaints reply was successfully destroyed.' }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_complaints_reply
      @complaints_reply = ComplaintsReply.find(params[:id])
    end

    # Only allow a list of trusted parameters through.
    def complaints_reply_params
      params.require(:complaints_reply).permit(:reply, :employee_id, :complaint_id, :attachment_id, :replyEmployeeId_id)
    end
end
