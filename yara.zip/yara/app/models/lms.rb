class Lms < ApplicationRecord
  belongs_to :leave_type
  belongs_to :leave_approver, class_name: 'Employee', foreign_key: 'employee_id'
  belongs_to :attachment
  belongs_to :employee
end
