require 'test_helper'

class ClaimApproversControllerTest < ActionDispatch::IntegrationTest
  setup do
    @claim_approver = claim_approvers(:one)
  end

  test "should get index" do
    get claim_approvers_url
    assert_response :success
  end

  test "should get new" do
    get new_claim_approver_url
    assert_response :success
  end

  test "should create claim_approver" do
    assert_difference('ClaimApprover.count') do
      post claim_approvers_url, params: { claim_approver: { department_role_id_id: @claim_approver.department_role_id_id } }
    end

    assert_redirected_to claim_approver_url(ClaimApprover.last)
  end

  test "should show claim_approver" do
    get claim_approver_url(@claim_approver)
    assert_response :success
  end

  test "should get edit" do
    get edit_claim_approver_url(@claim_approver)
    assert_response :success
  end

  test "should update claim_approver" do
    patch claim_approver_url(@claim_approver), params: { claim_approver: { department_role_id_id: @claim_approver.department_role_id_id } }
    assert_redirected_to claim_approver_url(@claim_approver)
  end

  test "should destroy claim_approver" do
    assert_difference('ClaimApprover.count', -1) do
      delete claim_approver_url(@claim_approver)
    end

    assert_redirected_to claim_approvers_url
  end
end
