require "application_system_test_case"

class LeaveTypesTest < ApplicationSystemTestCase
  setup do
    @leave_type = leave_types(:one)
  end

  test "visiting the index" do
    visit leave_types_url
    assert_selector "h1", text: "Leave Types"
  end

  test "creating a Leave type" do
    visit leave_types_url
    click_on "New Leave Type"

    check "Auto approve" if @leave_type.auto_approve
    check "Docs required" if @leave_type.docs_required
    fill_in "Holiday days", with: @leave_type.holiday_days
    fill_in "Leave disabled", with: @leave_type.leave_disabled
    fill_in "Leave name", with: @leave_type.leave_name
    fill_in "Leaves per month", with: @leave_type.leaves_per_month
    fill_in "Limits", with: @leave_type.limits
    fill_in "Location id", with: @leave_type.location_id_id
    click_on "Create Leave type"

    assert_text "Leave type was successfully created"
    click_on "Back"
  end

  test "updating a Leave type" do
    visit leave_types_url
    click_on "Edit", match: :first

    check "Auto approve" if @leave_type.auto_approve
    check "Docs required" if @leave_type.docs_required
    fill_in "Holiday days", with: @leave_type.holiday_days
    fill_in "Leave disabled", with: @leave_type.leave_disabled
    fill_in "Leave name", with: @leave_type.leave_name
    fill_in "Leaves per month", with: @leave_type.leaves_per_month
    fill_in "Limits", with: @leave_type.limits
    fill_in "Location id", with: @leave_type.location_id_id
    click_on "Update Leave type"

    assert_text "Leave type was successfully updated"
    click_on "Back"
  end

  test "destroying a Leave type" do
    visit leave_types_url
    page.accept_confirm do
      click_on "Destroy", match: :first
    end

    assert_text "Leave type was successfully destroyed"
  end
end
