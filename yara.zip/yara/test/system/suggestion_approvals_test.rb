require "application_system_test_case"

class SuggestionApprovalsTest < ApplicationSystemTestCase
  setup do
    @suggestion_approval = suggestion_approvals(:one)
  end

  test "visiting the index" do
    visit suggestion_approvals_url
    assert_selector "h1", text: "Suggestion Approvals"
  end

  test "creating a Suggestion approval" do
    visit suggestion_approvals_url
    click_on "New Suggestion Approval"

    fill_in "Rank", with: @suggestion_approval.rank
    fill_in "Role", with: @suggestion_approval.role_id
    fill_in "Suggestion approval id", with: @suggestion_approval.suggestion_approval_id_id
    click_on "Create Suggestion approval"

    assert_text "Suggestion approval was successfully created"
    click_on "Back"
  end

  test "updating a Suggestion approval" do
    visit suggestion_approvals_url
    click_on "Edit", match: :first

    fill_in "Rank", with: @suggestion_approval.rank
    fill_in "Role", with: @suggestion_approval.role_id
    fill_in "Suggestion approval id", with: @suggestion_approval.suggestion_approval_id_id
    click_on "Update Suggestion approval"

    assert_text "Suggestion approval was successfully updated"
    click_on "Back"
  end

  test "destroying a Suggestion approval" do
    visit suggestion_approvals_url
    page.accept_confirm do
      click_on "Destroy", match: :first
    end

    assert_text "Suggestion approval was successfully destroyed"
  end
end
