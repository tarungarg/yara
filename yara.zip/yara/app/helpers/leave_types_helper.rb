module LeaveTypesHelper
end
