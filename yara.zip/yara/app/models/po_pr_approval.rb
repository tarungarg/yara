class PoPrApproval < ApplicationRecord
  belongs_to :approved_id, class_name: 'Employee', foreign_key: 'employee_id'
end
