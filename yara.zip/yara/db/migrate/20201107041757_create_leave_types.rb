class CreateLeaveTypes < ActiveRecord::Migration[6.0]
  def change
    create_table :leave_types do |t|
      t.string :leave_name
      t.references :location_id, null: false, foreign_key: true
      t.boolean :auto_approve
      t.integer :limits
      t.boolean :docs_required
      t.integer :leaves_per_month
      t.text :leave_disabled
      t.text :holiday_days

      t.timestamps
    end
  end
end
