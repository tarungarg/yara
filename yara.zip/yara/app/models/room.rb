class Room < ApplicationRecord
  belongs_to :company_address
end
