require "application_system_test_case"

class LmsTest < ApplicationSystemTestCase
  setup do
    @lm = lms(:one)
  end

  test "visiting the index" do
    visit lms_url
    assert_selector "h1", text: "Lms"
  end

  test "creating a Lms" do
    visit lms_url
    click_on "New Lms"

    fill_in "Attachment id", with: @lm.attachment_id_id
    fill_in "Employee id", with: @lm.employee_id_id
    fill_in "Leave approver id", with: @lm.leave_approver_id_id
    fill_in "Leave type id", with: @lm.leave_type_id_id
    fill_in "Reason", with: @lm.reason
    fill_in "Reason by approver", with: @lm.reason_by_approver
    check "Status" if @lm.status
    click_on "Create Lms"

    assert_text "Lms was successfully created"
    click_on "Back"
  end

  test "updating a Lms" do
    visit lms_url
    click_on "Edit", match: :first

    fill_in "Attachment id", with: @lm.attachment_id_id
    fill_in "Employee id", with: @lm.employee_id_id
    fill_in "Leave approver id", with: @lm.leave_approver_id_id
    fill_in "Leave type id", with: @lm.leave_type_id_id
    fill_in "Reason", with: @lm.reason
    fill_in "Reason by approver", with: @lm.reason_by_approver
    check "Status" if @lm.status
    click_on "Update Lms"

    assert_text "Lms was successfully updated"
    click_on "Back"
  end

  test "destroying a Lms" do
    visit lms_url
    page.accept_confirm do
      click_on "Destroy", match: :first
    end

    assert_text "Lms was successfully destroyed"
  end
end
