class ClaimApprover < ApplicationRecord
  belongs_to :department_role
end
