require 'test_helper'

class SuggestionTypeTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
