class CreateLms < ActiveRecord::Migration[6.0]
  def change
    create_table :lms do |t|
      t.boolean :status
      t.references :leave_type_id, null: false, foreign_key: true
      t.references :leave_approver_id, null: false, foreign_key: true
      t.references :attachment_id, null: false, foreign_key: true
      t.references :employee_id, null: false, foreign_key: true
      t.text :reason
      t.text :reason_by_approver

      t.timestamps
    end
  end
end
