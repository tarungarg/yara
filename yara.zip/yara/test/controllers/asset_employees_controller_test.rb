require 'test_helper'

class AssetEmployeesControllerTest < ActionDispatch::IntegrationTest
  setup do
    @asset_employee = asset_employees(:one)
  end

  test "should get index" do
    get asset_employees_url
    assert_response :success
  end

  test "should get new" do
    get new_asset_employee_url
    assert_response :success
  end

  test "should create asset_employee" do
    assert_difference('AssetEmployee.count') do
      post asset_employees_url, params: { asset_employee: { asset_id: @asset_employee.asset_id, assigned_by_id: @asset_employee.assigned_by_id, employee_id: @asset_employee.employee_id } }
    end

    assert_redirected_to asset_employee_url(AssetEmployee.last)
  end

  test "should show asset_employee" do
    get asset_employee_url(@asset_employee)
    assert_response :success
  end

  test "should get edit" do
    get edit_asset_employee_url(@asset_employee)
    assert_response :success
  end

  test "should update asset_employee" do
    patch asset_employee_url(@asset_employee), params: { asset_employee: { asset_id: @asset_employee.asset_id, assigned_by_id: @asset_employee.assigned_by_id, employee_id: @asset_employee.employee_id } }
    assert_redirected_to asset_employee_url(@asset_employee)
  end

  test "should destroy asset_employee" do
    assert_difference('AssetEmployee.count', -1) do
      delete asset_employee_url(@asset_employee)
    end

    assert_redirected_to asset_employees_url
  end
end
