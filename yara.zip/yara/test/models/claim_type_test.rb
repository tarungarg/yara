require 'test_helper'

class ClaimTypeTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
