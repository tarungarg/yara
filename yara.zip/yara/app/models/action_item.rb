class ActionItem < ApplicationRecord
  belongs_to :meeting
  belongs_to :assigned_to, class_name: 'Employee', foreign_key: 'employee_id'
  belongs_to :group
end
