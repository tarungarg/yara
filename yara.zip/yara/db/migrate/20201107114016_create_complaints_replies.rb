class CreateComplaintsReplies < ActiveRecord::Migration[6.0]
  def change
    create_table :complaints_replies do |t|
      t.text :reply
      t.references :employee, null: false, foreign_key: true
      t.references :complaint, null: false, foreign_key: true
      t.references :attachment, null: false, foreign_key: true
      t.references :replyEmployeeId, null: false, foreign_key: true

      t.timestamps
    end
  end
end
