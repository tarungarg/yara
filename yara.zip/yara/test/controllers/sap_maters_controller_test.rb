require 'test_helper'

class SapMatersControllerTest < ActionDispatch::IntegrationTest
  setup do
    @sap_mater = sap_maters(:one)
  end

  test "should get index" do
    get sap_maters_url
    assert_response :success
  end

  test "should get new" do
    get new_sap_mater_url
    assert_response :success
  end

  test "should create sap_mater" do
    assert_difference('SapMater.count') do
      post sap_maters_url, params: { sap_mater: { approved_id_id: @sap_mater.approved_id_id, status: @sap_mater.status } }
    end

    assert_redirected_to sap_mater_url(SapMater.last)
  end

  test "should show sap_mater" do
    get sap_mater_url(@sap_mater)
    assert_response :success
  end

  test "should get edit" do
    get edit_sap_mater_url(@sap_mater)
    assert_response :success
  end

  test "should update sap_mater" do
    patch sap_mater_url(@sap_mater), params: { sap_mater: { approved_id_id: @sap_mater.approved_id_id, status: @sap_mater.status } }
    assert_redirected_to sap_mater_url(@sap_mater)
  end

  test "should destroy sap_mater" do
    assert_difference('SapMater.count', -1) do
      delete sap_mater_url(@sap_mater)
    end

    assert_redirected_to sap_maters_url
  end
end
