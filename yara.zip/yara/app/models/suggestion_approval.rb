class SuggestionApproval < ApplicationRecord
  belongs_to :role
  belongs_to :suggestion_approval_id, class_name: 'Employee', foreign_key: 'employee_id'
end
