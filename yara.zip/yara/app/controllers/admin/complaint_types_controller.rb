class Admin::ComplaintTypesController < ApplicationController
  before_action :set_admin_complaint_type, only: [:show, :edit, :update, :destroy]

  # GET /admin/complaint_types
  # GET /admin/complaint_types.json
  def index
    @admin_complaint_types = ComplaintType.all
  end

  # GET /admin/complaint_types/1
  # GET /admin/complaint_types/1.json
  def show
  end

  # GET /admin/complaint_types/new
  def new
    @admin_complaint_type = ComplaintType.new
  end

  # GET /admin/complaint_types/1/edit
  def edit
  end

  # POST /admin/complaint_types
  # POST /admin/complaint_types.json
  def create
    @admin_complaint_type = ComplaintType.new(admin_complaint_type_params)

    respond_to do |format|
      if @admin_complaint_type.save
        format.html { redirect_to @admin_complaint_type, notice: 'Complaint type was successfully created.' }
        format.json { render :show, status: :created, location: @admin_complaint_type }
      else
        format.html { render :new }
        format.json { render json: @admin_complaint_type.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /admin/complaint_types/1
  # PATCH/PUT /admin/complaint_types/1.json
  def update
    respond_to do |format|
      if @admin_complaint_type.update(admin_complaint_type_params)
        format.html { redirect_to @admin_complaint_type, notice: 'Complaint type was successfully updated.' }
        format.json { render :show, status: :ok, location: @admin_complaint_type }
      else
        format.html { render :edit }
        format.json { render json: @admin_complaint_type.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /admin/complaint_types/1
  # DELETE /admin/complaint_types/1.json
  def destroy
    @admin_complaint_type.destroy
    respond_to do |format|
      format.html { redirect_to admin_complaint_types_url, notice: 'Complaint type was successfully destroyed.' }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_admin_complaint_type
      @admin_complaint_type = ComplaintType.find(params[:id])
    end

    # Only allow a list of trusted parameters through.
    def admin_complaint_type_params
      params.require(:admin_complaint_type).permit(:role_id, :complaint_type)
    end
end
