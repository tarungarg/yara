require "application_system_test_case"

class ComplaintsRepliesTest < ApplicationSystemTestCase
  setup do
    @complaints_reply = complaints_replies(:one)
  end

  test "visiting the index" do
    visit complaints_replies_url
    assert_selector "h1", text: "Complaints Replies"
  end

  test "creating a Complaints reply" do
    visit complaints_replies_url
    click_on "New Complaints Reply"

    fill_in "Attachment", with: @complaints_reply.attachment_id
    fill_in "Complaint", with: @complaints_reply.complaint_id
    fill_in "Employee", with: @complaints_reply.employee_id
    fill_in "Reply", with: @complaints_reply.reply
    fill_in "Replyemployeeid", with: @complaints_reply.replyEmployeeId_id
    click_on "Create Complaints reply"

    assert_text "Complaints reply was successfully created"
    click_on "Back"
  end

  test "updating a Complaints reply" do
    visit complaints_replies_url
    click_on "Edit", match: :first

    fill_in "Attachment", with: @complaints_reply.attachment_id
    fill_in "Complaint", with: @complaints_reply.complaint_id
    fill_in "Employee", with: @complaints_reply.employee_id
    fill_in "Reply", with: @complaints_reply.reply
    fill_in "Replyemployeeid", with: @complaints_reply.replyEmployeeId_id
    click_on "Update Complaints reply"

    assert_text "Complaints reply was successfully updated"
    click_on "Back"
  end

  test "destroying a Complaints reply" do
    visit complaints_replies_url
    page.accept_confirm do
      click_on "Destroy", match: :first
    end

    assert_text "Complaints reply was successfully destroyed"
  end
end
