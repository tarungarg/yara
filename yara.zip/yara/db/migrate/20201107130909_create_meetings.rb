class CreateMeetings < ActiveRecord::Migration[6.0]
  def change
    create_table :meetings do |t|
      t.string :meeting_name
      t.text :invites
      t.string :meeting_link
      t.text :accepted
      t.text :rejected
      t.text :mom
      t.text :desc
      t.references :company_address, null: false, foreign_key: true
      t.references :admin_id, null: false, foreign_key: true
      t.references :room_time_slot, null: false, foreign_key: true

      t.timestamps
    end
  end
end
