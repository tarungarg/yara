require 'test_helper'

class CmTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
