require "application_system_test_case"

class TravelRequestsTest < ApplicationSystemTestCase
  setup do
    @travel_request = travel_requests(:one)
  end

  test "visiting the index" do
    visit travel_requests_url
    assert_selector "h1", text: "Travel Requests"
  end

  test "creating a Travel request" do
    visit travel_requests_url
    click_on "New Travel Request"

    fill_in "Approval id", with: @travel_request.approval_id_id
    fill_in "Attachment", with: @travel_request.attachment_id
    fill_in "Desc", with: @travel_request.desc
    fill_in "Employee", with: @travel_request.employee_id
    fill_in "Status", with: @travel_request.status
    fill_in "Travel type", with: @travel_request.travel_type_id
    click_on "Create Travel request"

    assert_text "Travel request was successfully created"
    click_on "Back"
  end

  test "updating a Travel request" do
    visit travel_requests_url
    click_on "Edit", match: :first

    fill_in "Approval id", with: @travel_request.approval_id_id
    fill_in "Attachment", with: @travel_request.attachment_id
    fill_in "Desc", with: @travel_request.desc
    fill_in "Employee", with: @travel_request.employee_id
    fill_in "Status", with: @travel_request.status
    fill_in "Travel type", with: @travel_request.travel_type_id
    click_on "Update Travel request"

    assert_text "Travel request was successfully updated"
    click_on "Back"
  end

  test "destroying a Travel request" do
    visit travel_requests_url
    page.accept_confirm do
      click_on "Destroy", match: :first
    end

    assert_text "Travel request was successfully destroyed"
  end
end
