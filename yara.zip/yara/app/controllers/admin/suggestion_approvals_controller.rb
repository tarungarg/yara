class Admin::SuggestionApprovalsController < ApplicationController
  before_action :set_suggestion_approval, only: [:show, :edit, :update, :destroy]

  # GET /suggestion_approvals
  # GET /suggestion_approvals.json
  def index
    @suggestion_approvals = SuggestionApproval.all
  end

  # GET /suggestion_approvals/1
  # GET /suggestion_approvals/1.json
  def show
  end

  # GET /suggestion_approvals/new
  def new
    @suggestion_approval = SuggestionApproval.new
  end

  # GET /suggestion_approvals/1/edit
  def edit
  end

  # POST /suggestion_approvals
  # POST /suggestion_approvals.json
  def create
    @suggestion_approval = SuggestionApproval.new(suggestion_approval_params)

    respond_to do |format|
      if @suggestion_approval.save
        format.html { redirect_to @suggestion_approval, notice: 'Suggestion approval was successfully created.' }
        format.json { render :show, status: :created, location: @suggestion_approval }
      else
        format.html { render :new }
        format.json { render json: @suggestion_approval.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /suggestion_approvals/1
  # PATCH/PUT /suggestion_approvals/1.json
  def update
    respond_to do |format|
      if @suggestion_approval.update(suggestion_approval_params)
        format.html { redirect_to @suggestion_approval, notice: 'Suggestion approval was successfully updated.' }
        format.json { render :show, status: :ok, location: @suggestion_approval }
      else
        format.html { render :edit }
        format.json { render json: @suggestion_approval.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /suggestion_approvals/1
  # DELETE /suggestion_approvals/1.json
  def destroy
    @suggestion_approval.destroy
    respond_to do |format|
      format.html { redirect_to suggestion_approvals_url, notice: 'Suggestion approval was successfully destroyed.' }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_suggestion_approval
      @suggestion_approval = SuggestionApproval.find(params[:id])
    end

    # Only allow a list of trusted parameters through.
    def suggestion_approval_params
      params.require(:suggestion_approval).permit(:role_id, :rank, :suggestion_approval_id_id)
    end
end
