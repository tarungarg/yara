class ComplaintsReply < ApplicationRecord
  belongs_to :employee
  belongs_to :complaint
  belongs_to :attachment
  belongs_to :role
end
