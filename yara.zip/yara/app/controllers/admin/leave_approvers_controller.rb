class Admin::LeaveApproversController < ApplicationController
  before_action :set_leave_approver, only: [:show, :edit, :update, :destroy]

  # GET /leave_approvers
  # GET /leave_approvers.json
  def index
    @leave_approvers = LeaveApprover.all
  end

  # GET /leave_approvers/1
  # GET /leave_approvers/1.json
  def show
  end

  # GET /leave_approvers/new
  def new
    @leave_approver = LeaveApprover.new
  end

  # GET /leave_approvers/1/edit
  def edit
  end

  # POST /leave_approvers
  # POST /leave_approvers.json
  def create
    @leave_approver = LeaveApprover.new(leave_approver_params)

    respond_to do |format|
      if @leave_approver.save
        format.html { redirect_to @leave_approver, notice: 'Leave approver was successfully created.' }
        format.json { render :show, status: :created, location: @leave_approver }
      else
        format.html { render :new }
        format.json { render json: @leave_approver.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /leave_approvers/1
  # PATCH/PUT /leave_approvers/1.json
  def update
    respond_to do |format|
      if @leave_approver.update(leave_approver_params)
        format.html { redirect_to @leave_approver, notice: 'Leave approver was successfully updated.' }
        format.json { render :show, status: :ok, location: @leave_approver }
      else
        format.html { render :edit }
        format.json { render json: @leave_approver.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /leave_approvers/1
  # DELETE /leave_approvers/1.json
  def destroy
    @leave_approver.destroy
    respond_to do |format|
      format.html { redirect_to leave_approvers_url, notice: 'Leave approver was successfully destroyed.' }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_leave_approver
      @leave_approver = LeaveApprover.find(params[:id])
    end

    # Only allow a list of trusted parameters through.
    def leave_approver_params
      params.require(:leave_approver).permit(:leave_type_id, :leave_applied_by, :leave_approvers)
    end
end
