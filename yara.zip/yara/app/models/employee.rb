class Employee < ApplicationRecord
  belongs_to :department_role_id
end
