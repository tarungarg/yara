require 'test_helper'

class SapApprovalTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
