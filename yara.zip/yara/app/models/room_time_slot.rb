class RoomTimeSlot < ApplicationRecord
  belongs_to :room
end
