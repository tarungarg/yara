class Asset < ApplicationRecord
  belongs_to :employee
  belongs_to :department
  belongs_to :assigned_by, class_name: 'Employee', foreign_key: 'employee_id'
end
