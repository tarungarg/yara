class Suggestion < ApplicationRecord
  belongs_to :suggestion_type
  belongs_to :approved_id, class_name: 'Employee', foreign_key: 'employee_id'
  belongs_to :attachment
end
