class Admin::SapMatersController < ApplicationController
  before_action :set_sap_mater, only: [:show, :edit, :update, :destroy]

  # GET /sap_maters
  # GET /sap_maters.json
  def index
    @sap_maters = SapMater.all
  end

  # GET /sap_maters/1
  # GET /sap_maters/1.json
  def show
  end

  # GET /sap_maters/new
  def new
    @sap_mater = SapMater.new
  end

  # GET /sap_maters/1/edit
  def edit
  end

  # POST /sap_maters
  # POST /sap_maters.json
  def create
    @sap_mater = SapMater.new(sap_mater_params)

    respond_to do |format|
      if @sap_mater.save
        format.html { redirect_to @sap_mater, notice: 'Sap mater was successfully created.' }
        format.json { render :show, status: :created, location: @sap_mater }
      else
        format.html { render :new }
        format.json { render json: @sap_mater.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /sap_maters/1
  # PATCH/PUT /sap_maters/1.json
  def update
    respond_to do |format|
      if @sap_mater.update(sap_mater_params)
        format.html { redirect_to @sap_mater, notice: 'Sap mater was successfully updated.' }
        format.json { render :show, status: :ok, location: @sap_mater }
      else
        format.html { render :edit }
        format.json { render json: @sap_mater.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /sap_maters/1
  # DELETE /sap_maters/1.json
  def destroy
    @sap_mater.destroy
    respond_to do |format|
      format.html { redirect_to sap_maters_url, notice: 'Sap mater was successfully destroyed.' }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_sap_mater
      @sap_mater = SapMater.find(params[:id])
    end

    # Only allow a list of trusted parameters through.
    def sap_mater_params
      params.require(:sap_mater).permit(:approved_id_id, :status)
    end
end
