class CreateSuggestionTypes < ActiveRecord::Migration[6.0]
  def change
    create_table :suggestion_types do |t|
      t.string :suggestion_type
      t.string :reward_type
      t.integer :reward_amount

      t.timestamps
    end
  end
end
