module AssetsHelper
end
