class CreateSapApprovals < ActiveRecord::Migration[6.0]
  def change
    create_table :sap_approvals do |t|
      t.references :approval_id, null: false, foreign_key: true
      t.references :sap_master, null: false, foreign_key: true
      t.integer :rank

      t.timestamps
    end
  end
end
